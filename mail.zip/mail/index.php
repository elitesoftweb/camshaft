<!DOCTYPE html>
<html lang="en">
<head>


<?php 
	session_start();
?>

  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>
<?php

	
	
	
	
	 use PHPMailer\PHPMailer\PHPMailer;
   
    function sendalert($sender) {
   

   
    
    require_once __DIR__ . '/vendor/phpmailer/src/Exception.php';
    require_once __DIR__ . '/vendor/phpmailer/src/PHPMailer.php';
    require_once __DIR__ . '/vendor/phpmailer/src/SMTP.php';
    
    // passing true in constructor enables exceptions in PHPMailer
    
	
	$mail = new PHPMailer(true);
    
    try {
        // Server settings
		

   




$prasad = "william@camshaftgroup.com"; //gmail of the sender
$bandara = "Dylan01!!"; //the password
$john = $sender; // the receiver email


                   
//Create a new PHPMailer instance
$mail = new PHPMailer;
$mail->SMTPDebug = 0;  // Enable verbose debug output

//SMTP settings start
$mail->isSMTP(); // Set mailer to use SMTP
$mail->Host = 'localhost'; // Specify main and backup SMTP servers
$mail->SMTPAuth = false; // Enable SMTP authentication
$mail->Username = $prasad; // SMTP username
$mail->Password = $bandara; // SMTP password
$mail->SMTPAutoTLS = false; 
$mail->SMTPSecure = false; // Enable TLS encryption, `ssl` also accepted
$mail->Port = 25;

//Sender
$mail->setFrom('william@camshaftgroup.com');
//Receiver
$mail->addAddress('Dylan.george10@gmail.com');

//Email Subject & Body
$mail->Subject = 'New Form Submission';
//Form Fields
$mail->Body = 'Let me know if you received this.';

$mail->isHTML(true); // Set email format to HTML

//Send the message, check for errors
if (!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
}
else {
     echo 'Form Submitted Successfully.';
     // code for saving in data in database can be added here
}








    } catch (Exception $e) {
        
        echo "Error in sending email. Mailer Error: {$mail->ErrorInfo}";
    }

	}
	
	
	sendalert('rajithaprasad3@gmail.com');    

?>



</body>